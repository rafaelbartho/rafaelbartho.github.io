const tabuleiro = document.getElementById("tabuleiro");
const mensagem = document.getElementById("mensagem");
let jogador = "X";
let tab = Array(9).fill("");

function verificarVitoria() {
  const combinacoes = [
    [0,1,2], [3,4,5], [6,7,8],
    [0,3,6], [1,4,7], [2,5,8],
    [0,4,8], [2,4,6]
  ];
  for (let c of combinacoes) {
    const [a, b, c2] = c;
    if (tab[a] && tab[a] === tab[b] && tab[a] === tab[c2]) {
      return tab[a];
    }
  }
  return tab.includes("") ? null : "Empate";
}

function desenharTabuleiro() {
  tabuleiro.innerHTML = "";
  tab.forEach((valor, i) => {
    const celula = document.createElement("div");
    celula.textContent = valor;
    celula.onclick = () => {
      if (!tab[i] && !verificarVitoria()) {
        tab[i] = jogador;
        jogador = jogador === "X" ? "O" : "X";
        desenharTabuleiro();
        const vencedor = verificarVitoria();
        if (vencedor) {
          mensagem.textContent = vencedor === "Empate" ? "Empate!" : vencedor + " venceu!";
        }
      }
    };
    tabuleiro.appendChild(celula);
  });
}

desenharTabuleiro();
